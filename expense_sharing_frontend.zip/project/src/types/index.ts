export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl?: string;
}

export interface Group {
  id: string;
  name: string;
  description?: string;
  members: User[];
  createdAt: string;
  ownerId: string;
}

export interface ExpenseSplit {
  userId: string;
  amount: number;
  paid: boolean;
}

export interface Expense {
  id: string;
  groupId: string;
  description: string;
  amount: number;
  paidBy: string;
  splits: ExpenseSplit[];
  date: string;
  category?: string;
  notes?: string;
}

export interface Balance {
  userId: string;
  amount: number;
}

export interface GroupSummary {
  groupId: string;
  groupName: string;
  totalExpenses: number;
  userBalance: number;
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  read: boolean;
  createdAt: string;
  type: 'expense' | 'settlement' | 'group' | 'reminder';
  relatedId?: string; // ID of related expense or group
}

export interface Settlement {
  id: string;
  fromUserId: string;
  toUserId: string;
  amount: number;
  groupId: string;
  date: string;
  status: 'pending' | 'completed' | 'cancelled';
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}