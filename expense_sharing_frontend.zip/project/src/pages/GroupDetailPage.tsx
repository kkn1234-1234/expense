import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Header } from '../components/common/Header';
import { Button } from '../components/ui/Button';
import { ExpenseList } from '../components/expenses/ExpenseList';
import { Plus, Users, Clock, ChevronLeft, ExternalLink } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { Group, Expense } from '../types';
import { mockApi } from '../services/api';
import { format } from 'date-fns';

export const GroupDetailPage: React.FC = () => {
  const { groupId } = useParams<{ groupId: string }>();
  const { isAuthenticated, user } = useAuthStore();
  const navigate = useNavigate();
  const [group, setGroup] = useState<Group | null>(null);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchGroupData = async () => {
      try {
        if (!groupId) return;
        
        const groupsData = await mockApi.getGroups();
        const group = groupsData.find(g => g.id === groupId);
        
        if (!group) {
          navigate('/groups');
          return;
        }
        
        const expensesData = await mockApi.getExpenses(groupId);
        
        setGroup(group);
        setExpenses(expensesData);
        setLoading(false);
      } catch (error) {
        console.error('Failed to fetch group data:', error);
        setLoading(false);
      }
    };

    fetchGroupData();
  }, [groupId, isAuthenticated, navigate]);

  if (!isAuthenticated || !groupId || loading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!group) return null;
  
  // Calculate balances
  const calculateBalances = () => {
    const balances: Record<string, number> = {};
    
    // Initialize balances for all members
    group.members.forEach(member => {
      balances[member.id] = 0;
    });
    
    // Calculate balances based on expenses
    expenses.forEach(expense => {
      const payer = expense.paidBy;
      const totalAmount = expense.amount;
      
      // Add the full amount to the payer's balance (positive means others owe them)
      balances[payer] += totalAmount;
      
      // Subtract each person's share
      expense.splits.forEach(split => {
        balances[split.userId] -= split.amount;
      });
    });
    
    return balances;
  };
  
  const balances = calculateBalances();
  const totalExpenses = expenses.reduce((sum, expense) => sum + expense.amount, 0);
  
  const getUserBalance = (userId: string) => {
    return balances[userId] || 0;
  };
  
  const currentUserBalance = user ? getUserBalance(user.id) : 0;
  
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6">
          <Link to="/groups" className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to Groups
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow overflow-hidden mb-6">
          <div className="px-6 py-5 border-b border-slate-200">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
              <h1 className="text-2xl font-bold text-slate-900">{group.name}</h1>
              
              <div className="mt-4 md:mt-0">
                <Link to={`/groups/${groupId}/expenses/new`}>
                  <Button icon={<Plus className="h-4 w-4" />}>
                    Add Expense
                  </Button>
                </Link>
              </div>
            </div>
            
            {group.description && (
              <p className="mt-2 text-slate-600">{group.description}</p>
            )}
          </div>
          
          <div className="px-6 py-4 grid grid-cols-1 md:grid-cols-3 gap-6 bg-slate-50">
            <div className="flex items-center">
              <Users className="h-5 w-5 text-slate-400 mr-2" />
              <div>
                <p className="text-sm font-medium text-slate-700">Members</p>
                <p className="text-slate-900">{group.members.length}</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <Clock className="h-5 w-5 text-slate-400 mr-2" />
              <div>
                <p className="text-sm font-medium text-slate-700">Created</p>
                <p className="text-slate-900">{format(new Date(group.createdAt), 'MMM d, yyyy')}</p>
              </div>
            </div>
            
            <div className="flex items-center">
              <ExternalLink className="h-5 w-5 text-slate-400 mr-2" />
              <div>
                <p className="text-sm font-medium text-slate-700">Total Expenses</p>
                <p className="text-slate-900">${totalExpenses.toFixed(2)}</p>
              </div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3">
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-200 flex justify-between items-center">
                <h2 className="text-lg font-semibold text-slate-800">Expenses</h2>
                
                {user && (
                  <div className={`text-sm font-medium ${currentUserBalance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                    {currentUserBalance >= 0 
                      ? `You are owed $${currentUserBalance.toFixed(2)}` 
                      : `You owe $${Math.abs(currentUserBalance).toFixed(2)}`}
                  </div>
                )}
              </div>
              
              <div className="p-6">
                {user && (
                  <ExpenseList
                    expenses={expenses}
                    members={group.members}
                    currentUserId={user.id}
                  />
                )}
              </div>
            </div>
          </div>
          
          <div>
            <div className="bg-white rounded-lg shadow overflow-hidden sticky top-6">
              <div className="px-6 py-4 border-b border-slate-200">
                <h2 className="text-lg font-semibold text-slate-800">Group Members</h2>
              </div>
              
              <div className="divide-y divide-slate-200">
                {group.members.map((member) => {
                  const balance = getUserBalance(member.id);
                  
                  return (
                    <div key={member.id} className="px-6 py-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div className="h-10 w-10 rounded-full bg-indigo-500 flex items-center justify-center text-white font-medium">
                            {member.name.charAt(0).toUpperCase()}
                          </div>
                          <div className="ml-3">
                            <p className="text-sm font-medium text-slate-800">
                              {member.name}
                              {member.id === group.ownerId && (
                                <span className="ml-2 text-xs bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded">
                                  Creator
                                </span>
                              )}
                            </p>
                            <p className="text-xs text-slate-500">{member.email}</p>
                          </div>
                        </div>
                        
                        <div className={`text-sm font-medium ${balance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                          {balance === 0 
                            ? 'Settled up' 
                            : balance > 0 
                              ? `+$${balance.toFixed(2)}` 
                              : `-$${Math.abs(balance).toFixed(2)}`}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};