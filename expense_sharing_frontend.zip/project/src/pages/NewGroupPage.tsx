import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Header } from '../components/common/Header';
import { GroupForm } from '../components/groups/GroupForm';
import { Link } from 'react-router-dom';
import { ChevronLeft } from 'lucide-react';
import { useAuthStore } from '../store/authStore';

export const NewGroupPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuthStore();

  React.useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
    }
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated || !user) return null;

  const handleSubmit = (data: any) => {
    // In a real app, you would send this data to your backend
    console.log('Creating group with data:', data);
    navigate('/groups');
  };

  const handleCancel = () => {
    navigate('/groups');
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link to="/groups" className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to Groups
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <h1 className="text-2xl font-bold text-slate-900 mb-6">Create a New Group</h1>
          
          <GroupForm
            onSubmit={handleSubmit}
            onCancel={handleCancel}
          />
        </div>
      </div>
    </div>
  );
};