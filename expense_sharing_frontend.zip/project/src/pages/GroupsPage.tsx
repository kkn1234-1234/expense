import React, { useEffect, useState } from 'react';
import { Header } from '../components/common/Header';
import { GroupCard } from '../components/groups/GroupCard';
import { Button } from '../components/ui/Button';
import { Plus, Search } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { Group } from '../types';
import { mockApi } from '../services/api';

export const GroupsPage: React.FC = () => {
  const { isAuthenticated } = useAuthStore();
  const navigate = useNavigate();
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchGroups = async () => {
      try {
        const data = await mockApi.getGroups();
        setGroups(data);
        setLoading(false);
      } catch (error) {
        console.error('Failed to fetch groups:', error);
        setLoading(false);
      }
    };

    fetchGroups();
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) return null;

  const filteredGroups = groups.filter(group => 
    group.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    group.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <h1 className="text-2xl font-bold text-slate-900">My Groups</h1>
          
          <div className="flex w-full sm:w-auto space-x-4">
            <div className="relative w-full sm:w-64">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                placeholder="Search groups"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <Link to="/groups/new">
              <Button icon={<Plus className="h-4 w-4" />}>
                New Group
              </Button>
            </Link>
          </div>
        </div>
        
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        ) : filteredGroups.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center">
            {searchTerm ? (
              <>
                <h3 className="text-lg font-medium text-slate-800">No matching groups found</h3>
                <p className="text-slate-500 mt-2">
                  Try adjusting your search or filter to find what you're looking for.
                </p>
              </>
            ) : (
              <>
                <h3 className="text-lg font-medium text-slate-800">You haven't created any groups yet</h3>
                <p className="text-slate-500 mt-2">
                  Get started by creating your first expense sharing group.
                </p>
                <div className="mt-4">
                  <Link to="/groups/new">
                    <Button>Create a Group</Button>
                  </Link>
                </div>
              </>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGroups.map((group) => (
              <GroupCard key={group.id} group={group} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};