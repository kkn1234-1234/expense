import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { Header } from '../components/common/Header';
import { DollarSign, Users, Smartphone, BarChart4, Clock, Shield } from 'lucide-react';

export const HomePage: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white">
      <Header />
      
      <main>
        {/* Hero section */}
        <section className="py-16 md:py-24">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h1 className="text-4xl md:text-5xl font-bold text-slate-900 leading-tight">
                  Split expenses with friends and family{' '}
                  <span className="text-indigo-600">effortlessly</span>
                </h1>
                <p className="mt-6 text-lg text-slate-600">
                  SplitWise makes it easy to share expenses with roommates, friends, and family.
                  Track who owes what, settle up, and get back to enjoying your time together.
                </p>
                <div className="mt-8 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
                  <Link to="/register">
                    <Button size="lg">
                      Get Started for Free
                    </Button>
                  </Link>
                  <Link to="/login">
                    <Button variant="outline" size="lg">
                      Sign In
                    </Button>
                  </Link>
                </div>
              </div>
              
              <div className="hidden md:block">
                <img
                  src="https://images.pexels.com/photos/7821579/pexels-photo-7821579.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                  alt="Friends splitting expenses"
                  className="rounded-lg shadow-lg"
                />
              </div>
            </div>
          </div>
        </section>
        
        {/* Features section */}
        <section className="py-16 bg-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-slate-900">How SplitWise Works</h2>
              <p className="mt-4 text-lg text-slate-600 max-w-3xl mx-auto">
                Simplify your shared expenses with our intuitive expense splitting app
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="p-6 bg-slate-50 rounded-lg">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">Create Groups</h3>
                <p className="text-slate-600">
                  Organize expenses by creating groups for roommates, trips, or any shared spending
                </p>
              </div>
              
              <div className="p-6 bg-slate-50 rounded-lg">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <DollarSign className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">Add Expenses</h3>
                <p className="text-slate-600">
                  Record expenses with customizable splits to ensure everyone pays their fair share
                </p>
              </div>
              
              <div className="p-6 bg-slate-50 rounded-lg">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                  <BarChart4 className="h-6 w-6 text-indigo-600" />
                </div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">Track Balances</h3>
                <p className="text-slate-600">
                  See who owes what at a glance with clear summaries of all balances
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Benefits section */}
        <section className="py-16 bg-slate-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-slate-900">Why Choose SplitWise</h2>
              <p className="mt-4 text-lg text-slate-600 max-w-3xl mx-auto">
                Our expense sharing app is designed to make your life easier
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                    <Smartphone className="h-5 w-5 text-indigo-600" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-slate-900">Easy to Use</h3>
                  <p className="mt-2 text-slate-600">
                    Simple, intuitive interface that makes expense tracking painless
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                    <Clock className="h-5 w-5 text-indigo-600" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-slate-900">Save Time</h3>
                  <p className="mt-2 text-slate-600">
                    Quickly add expenses and let our app handle all the math
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 bg-indigo-100 rounded-full flex items-center justify-center">
                    <Shield className="h-5 w-5 text-indigo-600" />
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-slate-900">Secure</h3>
                  <p className="mt-2 text-slate-600">
                    Your data is protected and private with our secure platform
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA section */}
        <section className="py-16 bg-indigo-600">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-white">
              Ready to simplify expense sharing?
            </h2>
            <p className="mt-4 text-lg text-indigo-100 max-w-3xl mx-auto">
              Join thousands of users who have already transformed how they manage shared expenses
            </p>
            <div className="mt-8">
              <Link to="/register">
                <Button
                  size="lg"
                  className="bg-white text-indigo-600 hover:bg-indigo-50"
                >
                  Sign Up Now
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      
      <footer className="bg-slate-900 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <p className="text-white font-bold text-xl">SplitWise</p>
              <p className="mt-2 text-slate-400 text-sm">
                The simplest way to share expenses
              </p>
            </div>
            
            <div className="flex space-x-6">
              <a href="#" className="text-slate-400 hover:text-white">
                Terms
              </a>
              <a href="#" className="text-slate-400 hover:text-white">
                Privacy
              </a>
              <a href="#" className="text-slate-400 hover:text-white">
                Help
              </a>
              <a href="#" className="text-slate-400 hover:text-white">
                Contact
              </a>
            </div>
          </div>
          
          <div className="mt-8 border-t border-slate-800 pt-8 text-center md:text-left">
            <p className="text-slate-400 text-sm">
              &copy; {new Date().getFullYear()} SplitWise. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};