import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Header } from '../components/common/Header';
import { ExpenseForm } from '../components/expenses/ExpenseForm';
import { ChevronLeft } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { Group } from '../types';
import { mockApi } from '../services/api';

export const NewExpensePage: React.FC = () => {
  const { groupId } = useParams<{ groupId: string }>();
  const navigate = useNavigate();
  const { isAuthenticated } = useAuthStore();
  const [group, setGroup] = useState<Group | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchGroup = async () => {
      try {
        if (!groupId) {
          navigate('/groups');
          return;
        }

        const groups = await mockApi.getGroups();
        const foundGroup = groups.find(g => g.id === groupId);

        if (!foundGroup) {
          navigate('/groups');
          return;
        }

        setGroup(foundGroup);
        setLoading(false);
      } catch (error) {
        console.error('Failed to fetch group:', error);
        setLoading(false);
      }
    };

    fetchGroup();
  }, [groupId, isAuthenticated, navigate]);

  if (!isAuthenticated) return null;

  const handleSubmit = (data: any) => {
    // In a real app, you would send this data to your backend
    console.log('Creating expense with data:', data);
    navigate(`/groups/${groupId}`);
  };

  const handleCancel = () => {
    navigate(`/groups/${groupId}`);
  };

  if (loading || !group) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Header />
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Link to={`/groups/${groupId}`} className="inline-flex items-center text-indigo-600 hover:text-indigo-700">
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to {group.name}
          </Link>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <h1 className="text-2xl font-bold text-slate-900 mb-6">Add an Expense to {group.name}</h1>
          
          <ExpenseForm
            group={group}
            onSubmit={handleSubmit}
            onCancel={handleCancel}
          />
        </div>
      </div>
    </div>
  );
};