import React from 'react';
import { Link } from 'react-router-dom';
import { Header } from '../components/common/Header';
import { LoginForm } from '../components/auth/LoginForm';

export const LoginPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-md mx-auto mt-16 px-4 sm:px-6 lg:px-8">
        <div className="bg-white py-8 px-6 shadow rounded-lg">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Sign in to SplitWise</h1>
            <p className="mt-2 text-sm text-gray-600">
              Or{' '}
              <Link to="/register" className="font-medium text-indigo-600 hover:text-indigo-500">
                create a new account
              </Link>
            </p>
          </div>
          
          <LoginForm />
        </div>
      </div>
    </div>
  );
};