import React, { useEffect, useState } from 'react';
import { Header } from '../components/common/Header';
import { BalanceSummary } from '../components/dashboard/BalanceSummary';
import { GroupSummary } from '../components/dashboard/GroupSummary';
import { RecentActivity } from '../components/dashboard/RecentActivity';
import { Notifications } from '../components/dashboard/Notifications';
import { useAuthStore } from '../store/authStore';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { Plus } from 'lucide-react';
import { mockApi } from '../services/api';

export const DashboardPage: React.FC = () => {
  const { isAuthenticated } = useAuthStore();
  const navigate = useNavigate();
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    const fetchDashboardData = async () => {
      try {
        const data = await mockApi.getDashboardData();
        setDashboardData(data);
        setLoading(false);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [isAuthenticated, navigate]);

  if (!isAuthenticated) return null;

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-500"></div>
          </div>
        </div>
      </div>
    );
  }

  const { totalBalance, groupSummaries, recentActivity, notifications } = dashboardData;
  const youOwe = totalBalance < 0 ? Math.abs(totalBalance) : 0;
  const youAreOwed = totalBalance > 0 ? totalBalance : 0;

  return (
    <div className="min-h-screen bg-slate-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="mb-6 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-slate-900">Dashboard</h1>
          
          <div className="flex space-x-4">
            <Link to="/groups/new">
              <Button size="sm" icon={<Plus className="h-4 w-4" />}>
                Add Group
              </Button>
            </Link>
            <Link to="/expenses/new">
              <Button size="sm" icon={<Plus className="h-4 w-4" />}>
                Add Expense
              </Button>
            </Link>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <BalanceSummary
              totalBalance={totalBalance}
              youOwe={youOwe}
              youAreOwed={youAreOwed}
            />
          </div>
          
          <div>
            <Notifications notifications={notifications} />
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          <div className="lg:col-span-2">
            <GroupSummary groups={groupSummaries} />
          </div>
          
          <div>
            <RecentActivity activities={recentActivity} />
          </div>
        </div>
      </div>
    </div>
  );
};