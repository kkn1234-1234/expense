import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { jwtDecode } from 'jwt-decode';
import { AuthState, User } from '../types';

interface AuthStore extends AuthState {
  login: (token: string) => void;
  logout: () => void;
  updateUser: (user: User) => void;
}

export const useAuthStore = create<AuthStore>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,
      login: (token: string) => {
        try {
          const decoded = jwtDecode<{ sub: string; name: string; email: string }>(token);
          
          const user: User = {
            id: decoded.sub,
            name: decoded.name,
            email: decoded.email
          };
          
          set({ 
            user, 
            token, 
            isAuthenticated: true 
          });
        } catch (error) {
          console.error('Invalid token:', error);
          set({ 
            user: null, 
            token: null, 
            isAuthenticated: false 
          });
        }
      },
      logout: () => {
        set({ 
          user: null, 
          token: null, 
          isAuthenticated: false 
        });
      },
      updateUser: (user: User) => {
        set({ user });
      }
    }),
    {
      name: 'auth-storage',
    }
  )
);