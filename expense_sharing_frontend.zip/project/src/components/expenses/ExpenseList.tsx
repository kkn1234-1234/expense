import React from 'react';
import { Expense, User } from '../../types';
import { format } from 'date-fns';
import { DollarSign, Calendar, Tag, User as UserIcon } from 'lucide-react';
import { motion } from 'framer-motion';

interface ExpenseListProps {
  expenses: Expense[];
  members: User[];
  currentUserId: string;
}

export const ExpenseList: React.FC<ExpenseListProps> = ({
  expenses,
  members,
  currentUserId,
}) => {
  // Sort expenses by date (newest first)
  const sortedExpenses = [...expenses].sort((a, b) => {
    return new Date(b.date).getTime() - new Date(a.date).getTime();
  });

  const getMemberName = (userId: string) => {
    const member = members.find(m => m.id === userId);
    return member?.name || 'Unknown';
  };

  const getUserSplit = (expense: Expense) => {
    const userSplit = expense.splits.find(split => split.userId === currentUserId);
    return userSplit ? userSplit.amount : 0;
  };

  // Group expenses by month
  const groupedExpenses = sortedExpenses.reduce((acc, expense) => {
    const month = format(new Date(expense.date), 'MMMM yyyy');
    if (!acc[month]) {
      acc[month] = [];
    }
    acc[month].push(expense);
    return acc;
  }, {} as Record<string, Expense[]>);

  const ExpenseItem = ({ expense }: { expense: Expense }) => {
    const paidByName = getMemberName(expense.paidBy);
    const userOwes = getUserSplit(expense);
    const isUserPayer = expense.paidBy === currentUserId;

    return (
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.2 }}
        className="bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden hover:shadow-md transition-shadow"
      >
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-200">
          <div className="flex justify-between items-center">
            <h3 className="text-md font-medium text-slate-800">{expense.description}</h3>
            <div className="text-md font-semibold text-slate-800">${expense.amount.toFixed(2)}</div>
          </div>
        </div>
        
        <div className="px-4 py-3 space-y-2">
          <div className="flex justify-between text-sm">
            <div className="flex items-center text-slate-600">
              <UserIcon className="h-4 w-4 mr-1" />
              <span>
                {isUserPayer ? 'You paid' : `${paidByName} paid`}
              </span>
            </div>
            <div className="flex items-center text-slate-600">
              <Calendar className="h-4 w-4 mr-1" />
              <span>{format(new Date(expense.date), 'MMM d, yyyy')}</span>
            </div>
          </div>
          
          {expense.category && (
            <div className="flex items-center text-sm text-slate-600">
              <Tag className="h-4 w-4 mr-1" />
              <span>{expense.category}</span>
            </div>
          )}
          
          <div className="pt-2 mt-2 border-t border-slate-200">
            <div className="flex justify-between items-center">
              <div className="text-sm text-slate-600">
                {isUserPayer ? 'You get back:' : 'Your share:'}
              </div>
              <div className={`text-sm font-medium ${isUserPayer ? 'text-emerald-600' : 'text-red-600'}`}>
                {isUserPayer 
                  ? `+$${(expense.amount - userOwes).toFixed(2)}` 
                  : `-$${userOwes.toFixed(2)}`}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    );
  };

  return (
    <div className="space-y-6">
      {Object.keys(groupedExpenses).length === 0 ? (
        <div className="text-center py-8">
          <DollarSign className="h-12 w-12 mx-auto text-slate-300" />
          <h3 className="mt-4 text-lg font-medium text-slate-800">No expenses yet</h3>
          <p className="mt-1 text-sm text-slate-500">
            Add your first expense to start tracking who owes what.
          </p>
        </div>
      ) : (
        Object.entries(groupedExpenses).map(([month, monthExpenses]) => (
          <div key={month}>
            <h2 className="text-md font-semibold text-slate-700 mb-3">{month}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {monthExpenses.map(expense => (
                <ExpenseItem key={expense.id} expense={expense} />
              ))}
            </div>
          </div>
        ))
      )}
    </div>
  );
};