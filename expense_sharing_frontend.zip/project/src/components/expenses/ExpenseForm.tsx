import React, { useState } from 'react';
import { useForm, useFieldArray } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { User, Group } from '../../types';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { DollarSign, Calendar, Tag, AlignLeft, Users, Plus, Minus } from 'lucide-react';
import { format } from 'date-fns';

const expenseSchema = z.object({
  description: z.string().min(1, 'Description is required'),
  amount: z.string().refine(val => !isNaN(Number(val)) && Number(val) > 0, {
    message: 'Amount must be a positive number',
  }),
  date: z.string(),
  category: z.string().optional(),
  notes: z.string().optional(),
  paidBy: z.string(),
  splitEqually: z.boolean(),
  splits: z.array(
    z.object({
      userId: z.string(),
      amount: z.string(),
    })
  ),
});

type ExpenseFormValues = z.infer<typeof expenseSchema>;

interface ExpenseFormProps {
  group: Group;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}

export const ExpenseForm: React.FC<ExpenseFormProps> = ({
  group,
  onSubmit,
  onCancel,
}) => {
  const [splitEqually, setSplitEqually] = useState(true);
  
  const { 
    register, 
    handleSubmit, 
    control,
    watch,
    setValue,
    formState: { errors, isSubmitting } 
  } = useForm<ExpenseFormValues>({
    resolver: zodResolver(expenseSchema),
    defaultValues: {
      description: '',
      amount: '',
      date: format(new Date(), 'yyyy-MM-dd'),
      category: '',
      notes: '',
      paidBy: group.members[0].id,
      splitEqually: true,
      splits: group.members.map(member => ({
        userId: member.id,
        amount: '',
      })),
    },
  });

  const { fields } = useFieldArray({
    control,
    name: 'splits',
  });

  const amount = watch('amount');
  const paidBy = watch('paidBy');

  // Calculate equal splits when amount changes
  React.useEffect(() => {
    if (splitEqually && amount) {
      const numMembers = group.members.length;
      const amountPerPerson = (parseFloat(amount) / numMembers).toFixed(2);
      
      fields.forEach((field, index) => {
        setValue(`splits.${index}.amount`, amountPerPerson);
      });
    }
  }, [amount, splitEqually, fields, setValue, group.members.length]);

  const handleSplitTypeChange = (isEqual: boolean) => {
    setSplitEqually(isEqual);
    setValue('splitEqually', isEqual);
    
    if (isEqual && amount) {
      const numMembers = group.members.length;
      const amountPerPerson = (parseFloat(amount) / numMembers).toFixed(2);
      
      fields.forEach((field, index) => {
        setValue(`splits.${index}.amount`, amountPerPerson);
      });
    }
  };

  const onFormSubmit = (data: ExpenseFormValues) => {
    // Convert form data to the right format
    const formattedData = {
      ...data,
      amount: parseFloat(data.amount),
      splits: data.splits.map(split => ({
        userId: split.userId,
        amount: parseFloat(split.amount),
        paid: split.userId === data.paidBy,
      })),
    };
    
    onSubmit(formattedData);
  };

  return (
    <form onSubmit={handleSubmit(onFormSubmit)} className="space-y-6">
      <Input
        id="description"
        label="Description"
        placeholder="Dinner, Groceries, etc."
        error={errors.description?.message}
        icon={<AlignLeft className="h-5 w-5" />}
        {...register('description')}
      />
      
      <Input
        id="amount"
        label="Amount"
        placeholder="0.00"
        error={errors.amount?.message}
        icon={<DollarSign className="h-5 w-5" />}
        {...register('amount')}
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Input
          id="date"
          type="date"
          label="Date"
          icon={<Calendar className="h-5 w-5" />}
          {...register('date')}
        />
        
        <Input
          id="category"
          label="Category (optional)"
          placeholder="Food, Transport, etc."
          icon={<Tag className="h-5 w-5" />}
          {...register('category')}
        />
      </div>
      
      <div className="space-y-2">
        <label className="block text-sm font-medium text-slate-700">Paid by</label>
        <div className="flex flex-wrap gap-2">
          {group.members.map((member) => (
            <label
              key={member.id}
              className={`
                inline-flex items-center px-3 py-2 border rounded-md text-sm font-medium cursor-pointer
                ${
                  paidBy === member.id
                    ? 'bg-indigo-100 border-indigo-300 text-indigo-800'
                    : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                }
              `}
            >
              <input
                type="radio"
                className="sr-only"
                value={member.id}
                {...register('paidBy')}
              />
              <span>{member.name}</span>
            </label>
          ))}
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <label className="block text-sm font-medium text-slate-700">Split options</label>
          <div className="inline-flex rounded-md shadow-sm">
            <button
              type="button"
              className={`relative inline-flex items-center px-3 py-2 rounded-l-md border text-sm font-medium ${
                splitEqually
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
              onClick={() => handleSplitTypeChange(true)}
            >
              Equal
            </button>
            <button
              type="button"
              className={`relative inline-flex items-center px-3 py-2 rounded-r-md border text-sm font-medium ${
                !splitEqually
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
              }`}
              onClick={() => handleSplitTypeChange(false)}
            >
              Custom
            </button>
          </div>
        </div>
        
        <div>
          <div className="bg-gray-50 px-4 py-2 rounded-t-md border border-gray-200">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-sm font-medium text-gray-700">Person</div>
              <div className="text-sm font-medium text-gray-700">Amount</div>
            </div>
          </div>
          
          <div className="divide-y divide-gray-200 border-x border-b border-gray-200 rounded-b-md">
            {fields.map((field, index) => {
              const member = group.members.find(m => m.id === field.userId);
              return (
                <div key={field.id} className="px-4 py-3">
                  <div className="grid grid-cols-2 gap-4 items-center">
                    <div className="text-sm text-gray-800">{member?.name}</div>
                    <div>
                      <Input
                        id={`splits.${index}.amount`}
                        placeholder="0.00"
                        className={splitEqually ? 'bg-gray-100' : ''}
                        icon={<DollarSign className="h-4 w-4" />}
                        {...register(`splits.${index}.amount`)}
                        disabled={splitEqually}
                      />
                      <input
                        type="hidden"
                        {...register(`splits.${index}.userId`)}
                        value={field.userId}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
      
      <Input
        id="notes"
        label="Notes (optional)"
        placeholder="Any additional details..."
        {...register('notes')}
      />
      
      <div className="flex justify-end space-x-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
        >
          Cancel
        </Button>
        
        <Button
          type="submit"
          isLoading={isSubmitting}
        >
          Save Expense
        </Button>
      </div>
    </form>
  );
};