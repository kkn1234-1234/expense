import React from 'react';
import { Link } from 'react-router-dom';
import { GroupSummary as GroupSummaryType } from '../../types';
import { ChevronRight } from 'lucide-react';

interface GroupSummaryProps {
  groups: GroupSummaryType[];
}

export const GroupSummary: React.FC<GroupSummaryProps> = ({ groups }) => {
  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-200">
        <h2 className="text-lg font-semibold text-slate-800">My Groups</h2>
      </div>
      
      <div className="divide-y divide-slate-200">
        {groups.length === 0 ? (
          <div className="px-6 py-4 text-center text-slate-500">
            <p>You haven't joined any groups yet.</p>
            <Link to="/groups/new" className="text-indigo-600 hover:text-indigo-800 font-medium">
              Create a group
            </Link>
          </div>
        ) : (
          groups.map((group) => (
            <div
              key={group.groupId}
              className="px-6 py-4 hover:bg-slate-50 transition-colors"
            >
              <Link to={`/groups/${group.groupId}`} className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium text-slate-800">{group.groupName}</h3>
                  <p className="text-xs text-slate-500 mt-1">
                    Total expenses: ${group.totalExpenses.toFixed(2)}
                  </p>
                </div>
                
                <div className="flex items-center">
                  <span className={`text-sm font-medium ${group.userBalance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                    {group.userBalance >= 0
                      ? `You are owed $${group.userBalance.toFixed(2)}`
                      : `You owe $${Math.abs(group.userBalance).toFixed(2)}`}
                  </span>
                  <ChevronRight className="h-5 w-5 text-slate-400 ml-2" />
                </div>
              </Link>
            </div>
          ))
        )}
      </div>
      
      <div className="px-6 py-4 border-t border-slate-200 bg-slate-50">
        <Link
          to="/groups"
          className="text-sm text-indigo-600 hover:text-indigo-800 font-medium"
        >
          View all groups
        </Link>
      </div>
    </div>
  );
};