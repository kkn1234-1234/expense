import React, { useState } from 'react';
import { format } from 'date-fns';
import { Notification } from '../../types';
import { Bell, Check, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface NotificationsProps {
  notifications: Notification[];
}

export const Notifications: React.FC<NotificationsProps> = ({ notifications }) => {
  const [visibleNotifications, setVisibleNotifications] = useState(notifications);

  const dismissNotification = (id: string) => {
    setVisibleNotifications(visibleNotifications.filter((n) => n.id !== id));
  };

  const markAsRead = (id: string) => {
    setVisibleNotifications(
      visibleNotifications.map((n) =>
        n.id === id ? { ...n, read: true } : n
      )
    );
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'expense':
        return <Bell className="h-5 w-5 text-indigo-500" />;
      case 'settlement':
        return <Bell className="h-5 w-5 text-emerald-500" />;
      case 'group':
        return <Bell className="h-5 w-5 text-blue-500" />;
      case 'reminder':
        return <Bell className="h-5 w-5 text-amber-500" />;
      default:
        return <Bell className="h-5 w-5 text-indigo-500" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-200">
        <h2 className="text-lg font-semibold text-slate-800">Notifications</h2>
      </div>
      
      <div className="divide-y divide-slate-200">
        <AnimatePresence>
          {visibleNotifications.length === 0 ? (
            <div className="px-6 py-4 text-center text-slate-500">
              <p>No new notifications.</p>
            </div>
          ) : (
            visibleNotifications.map((notification) => (
              <motion.div
                key={notification.id}
                initial={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className={`px-6 py-4 ${!notification.read ? 'bg-indigo-50' : 'hover:bg-slate-50'} transition-colors relative`}
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    {getNotificationIcon(notification.type)}
                  </div>
                  <div className="ml-3 flex-1 pr-8">
                    <div className="text-sm text-slate-800">{notification.message}</div>
                    <div className="text-xs text-slate-500 mt-1">
                      {format(new Date(notification.createdAt), 'MMM d, yyyy • h:mm a')}
                    </div>
                  </div>
                  <div className="absolute right-4 top-4 flex space-x-1">
                    {!notification.read && (
                      <button
                        onClick={() => markAsRead(notification.id)}
                        className="text-slate-400 hover:text-indigo-600"
                        title="Mark as read"
                      >
                        <Check className="h-4 w-4" />
                      </button>
                    )}
                    <button
                      onClick={() => dismissNotification(notification.id)}
                      className="text-slate-400 hover:text-red-600"
                      title="Dismiss"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};