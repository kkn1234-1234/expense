import React from 'react';
import { format } from 'date-fns';
import { DollarSign, UserPlus, CreditCard } from 'lucide-react';

interface Activity {
  id: string;
  description: string;
  date: string;
  type: 'expense' | 'settlement' | 'group';
}

interface RecentActivityProps {
  activities: Activity[];
}

export const RecentActivity: React.FC<RecentActivityProps> = ({ activities }) => {
  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'expense':
        return <DollarSign className="h-5 w-5 text-indigo-500" />;
      case 'settlement':
        return <CreditCard className="h-5 w-5 text-emerald-500" />;
      case 'group':
        return <UserPlus className="h-5 w-5 text-blue-500" />;
      default:
        return <DollarSign className="h-5 w-5 text-indigo-500" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-200">
        <h2 className="text-lg font-semibold text-slate-800">Recent Activity</h2>
      </div>
      
      <div className="divide-y divide-slate-200">
        {activities.length === 0 ? (
          <div className="px-6 py-4 text-center text-slate-500">
            <p>No recent activity to show.</p>
          </div>
        ) : (
          activities.map((activity) => (
            <div key={activity.id} className="px-6 py-4 hover:bg-slate-50 transition-colors">
              <div className="flex items-start">
                <div className="flex-shrink-0 mt-1">
                  {getActivityIcon(activity.type)}
                </div>
                <div className="ml-3 flex-1">
                  <div className="text-sm text-slate-800">{activity.description}</div>
                  <div className="text-xs text-slate-500 mt-1">
                    {format(new Date(activity.date), 'MMM d, yyyy • h:mm a')}
                  </div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
      
      <div className="px-6 py-4 border-t border-slate-200 bg-slate-50">
        <a
          href="/activity"
          className="text-sm text-indigo-600 hover:text-indigo-800 font-medium"
        >
          View all activity
        </a>
      </div>
    </div>
  );
};