import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';

ChartJS.register(ArcElement, Tooltip, Legend);

interface BalanceSummaryProps {
  totalBalance: number;
  youOwe: number;
  youAreOwed: number;
}

export const BalanceSummary: React.FC<BalanceSummaryProps> = ({
  totalBalance,
  youOwe,
  youAreOwed,
}) => {
  const chartData = {
    labels: ['You owe', 'You are owed'],
    datasets: [
      {
        data: [youOwe, youAreOwed],
        backgroundColor: ['#ef4444', '#10b981'],
        borderColor: ['#ef4444', '#10b981'],
        borderWidth: 1,
        hoverOffset: 4,
      },
    ],
  };

  const options = {
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          boxWidth: 12,
          padding: 20,
        },
      },
      tooltip: {
        callbacks: {
          label: function(context: any) {
            return `${context.label}: $${context.parsed}`;
          }
        }
      }
    },
    cutout: '70%',
    responsive: true,
    maintainAspectRatio: false,
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-lg font-semibold text-slate-800 mb-4">Balance Summary</h2>
      
      <div className="flex flex-col sm:flex-row justify-between mb-6">
        <div className="flex flex-col items-center mb-4 sm:mb-0">
          <p className="text-sm text-slate-500 mb-1">Total Balance</p>
          <p className={`text-2xl font-bold ${totalBalance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            ${Math.abs(totalBalance).toFixed(2)}
          </p>
          <p className="text-xs text-slate-500">
            {totalBalance >= 0 ? 'You are owed' : 'You owe'}
          </p>
        </div>
        
        <div className="flex flex-col items-center">
          <p className="text-sm text-slate-500 mb-1">You owe</p>
          <div className="flex items-center">
            <ArrowUpRight className="h-4 w-4 text-red-500 mr-1" />
            <p className="text-lg font-semibold text-red-500">${youOwe.toFixed(2)}</p>
          </div>
        </div>
        
        <div className="flex flex-col items-center">
          <p className="text-sm text-slate-500 mb-1">You are owed</p>
          <div className="flex items-center">
            <ArrowDownRight className="h-4 w-4 text-emerald-500 mr-1" />
            <p className="text-lg font-semibold text-emerald-500">${youAreOwed.toFixed(2)}</p>
          </div>
        </div>
      </div>
      
      <div className="h-56">
        <Doughnut data={chartData} options={options} />
      </div>
    </div>
  );
};