import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Users, AlignLeft } from 'lucide-react';

const groupSchema = z.object({
  name: z.string().min(1, 'Group name is required'),
  description: z.string().optional(),
  members: z.array(
    z.object({
      email: z.string().email('Please enter a valid email'),
      name: z.string().min(1, 'Name is required'),
    })
  ).min(1, 'At least one member is required'),
});

type GroupFormValues = z.infer<typeof groupSchema>;

interface GroupFormProps {
  onSubmit: (data: GroupFormValues) => void;
  onCancel: () => void;
}

export const GroupForm: React.FC<GroupFormProps> = ({ onSubmit, onCancel }) => {
  const { 
    register, 
    handleSubmit, 
    formState: { errors, isSubmitting } 
  } = useForm<GroupFormValues>({
    resolver: zodResolver(groupSchema),
    defaultValues: {
      name: '',
      description: '',
      members: [
        { email: '', name: '' },
      ],
    },
  });

  const [members, setMembers] = React.useState([{ id: 0 }]);

  const addMember = () => {
    setMembers([...members, { id: members.length }]);
  };

  const removeMember = (id: number) => {
    if (members.length > 1) {
      setMembers(members.filter(member => member.id !== id));
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <Input
        id="name"
        label="Group Name"
        placeholder="Roommates, Trip to Paris, etc."
        error={errors.name?.message}
        icon={<Users className="h-5 w-5" />}
        {...register('name')}
      />
      
      <Input
        id="description"
        label="Description (optional)"
        placeholder="What's this group for?"
        icon={<AlignLeft className="h-5 w-5" />}
        {...register('description')}
      />
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <label className="block text-sm font-medium text-slate-700">Group Members</label>
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={addMember}
          >
            Add Member
          </Button>
        </div>
        
        <div className="space-y-4">
          {members.map((member, index) => (
            <div key={member.id} className="flex space-x-4">
              <div className="flex-1">
                <Input
                  id={`members.${index}.name`}
                  placeholder="Name"
                  {...register(`members.${index}.name`)}
                  error={errors.members?.[index]?.name?.message}
                />
              </div>
              
              <div className="flex-1">
                <Input
                  id={`members.${index}.email`}
                  placeholder="Email"
                  {...register(`members.${index}.email`)}
                  error={errors.members?.[index]?.email?.message}
                />
              </div>
              
              {members.length > 1 && (
                <div className="flex items-end">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removeMember(member.id)}
                  >
                    Remove
                  </Button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
      
      <div className="flex justify-end space-x-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
        >
          Cancel
        </Button>
        
        <Button
          type="submit"
          isLoading={isSubmitting}
        >
          Create Group
        </Button>
      </div>
    </form>
  );
};