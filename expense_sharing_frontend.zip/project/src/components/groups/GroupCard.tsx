import React from 'react';
import { Link } from 'react-router-dom';
import { Group } from '../../types';
import { Users, Calendar } from 'lucide-react';
import { format } from 'date-fns';

interface GroupCardProps {
  group: Group;
}

export const GroupCard: React.FC<GroupCardProps> = ({ group }) => {
  return (
    <Link
      to={`/groups/${group.id}`}
      className="block bg-white rounded-lg overflow-hidden border border-slate-200 hover:shadow-md transition-shadow"
    >
      <div className="p-6">
        <h3 className="text-lg font-semibold text-slate-800 mb-2">{group.name}</h3>
        
        {group.description && (
          <p className="text-sm text-slate-600 mb-4">{group.description}</p>
        )}
        
        <div className="flex items-center space-x-4 text-sm text-slate-500">
          <div className="flex items-center">
            <Users className="h-4 w-4 mr-1" />
            <span>{group.members.length} {group.members.length === 1 ? 'member' : 'members'}</span>
          </div>
          
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-1" />
            <span>Created {format(new Date(group.createdAt), 'MMM d, yyyy')}</span>
          </div>
        </div>
      </div>
      
      <div className="bg-slate-50 px-6 py-3 border-t border-slate-200">
        <div className="flex overflow-hidden">
          {group.members.slice(0, 3).map((member, index) => (
            <div
              key={member.id}
              className={`h-8 w-8 rounded-full bg-indigo-500 flex items-center justify-center text-white text-xs font-medium -ml-${
                index > 0 ? 2 : 0
              }`}
              title={member.name}
            >
              {member.name.charAt(0).toUpperCase()}
            </div>
          ))}
          
          {group.members.length > 3 && (
            <div className="h-8 w-8 rounded-full bg-slate-300 flex items-center justify-center text-white text-xs font-medium -ml-2">
              +{group.members.length - 3}
            </div>
          )}
        </div>
      </div>
    </Link>
  );
};