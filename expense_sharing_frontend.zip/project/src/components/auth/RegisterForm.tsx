import React from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useNavigate } from 'react-router-dom';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { User, Mail, Lock } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { mockApi } from '../../services/api';

const registerSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Please enter a valid email'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  confirmPassword: z.string(),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

type RegisterFormValues = z.infer<typeof registerSchema>;

export const RegisterForm: React.FC = () => {
  const navigate = useNavigate();
  const { login } = useAuthStore();
  
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
    },
  });

  const onSubmit = async (data: RegisterFormValues) => {
    try {
      // In a real app, this would call your backend API
      const response = await mockApi.register(data.name, data.email, data.password);
      login(response.token);
      navigate('/dashboard');
    } catch (error) {
      console.error('Registration failed:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <Input
        id="name"
        type="text"
        label="Full name"
        error={errors.name?.message}
        icon={<User className="h-5 w-5" />}
        placeholder="John Doe"
        {...register('name')}
      />
      
      <Input
        id="email"
        type="email"
        label="Email address"
        error={errors.email?.message}
        icon={<Mail className="h-5 w-5" />}
        placeholder="you@example.com"
        {...register('email')}
      />
      
      <Input
        id="password"
        type="password"
        label="Password"
        error={errors.password?.message}
        icon={<Lock className="h-5 w-5" />}
        placeholder="••••••••"
        helperText="Must be at least 8 characters"
        {...register('password')}
      />
      
      <Input
        id="confirmPassword"
        type="password"
        label="Confirm password"
        error={errors.confirmPassword?.message}
        icon={<Lock className="h-5 w-5" />}
        placeholder="••••••••"
        {...register('confirmPassword')}
      />
      
      <Button type="submit" fullWidth isLoading={isSubmitting}>
        Create account
      </Button>
    </form>
  );
};