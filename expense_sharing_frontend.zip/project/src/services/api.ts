import axios from 'axios';
import { useAuthStore } from '../store/authStore';

// This would be updated to point to your actual API when deployed
const API_URL = 'https://api.your-expense-sharing-app.com';

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

api.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Mock data for development purposes
export const mockApi = {
  login: async (email: string, password: string) => {
    // In a real app, you would call an actual API endpoint
    // For now, we'll simulate a successful login with mock data
    return {
      token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyMTIzIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqb2huQGV4YW1wbGUuY29tIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c'
    };
  },
  register: async (name: string, email: string, password: string) => {
    // Simulate registration
    return {
      token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyMTIzIiwibmFtZSI6IkpvaG4gRG9lIiwiZW1haWwiOiJqb2huQGV4YW1wbGUuY29tIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c'
    };
  },
  getGroups: async () => {
    return [
      {
        id: 'group1',
        name: 'Roommates',
        description: 'Expenses for our apartment',
        members: [
          { id: 'user123', name: 'John Doe', email: 'john@example.com' },
          { id: 'user456', name: 'Jane Smith', email: 'jane@example.com' },
          { id: 'user789', name: 'Mike Johnson', email: 'mike@example.com' }
        ],
        createdAt: '2023-01-15T08:30:00Z',
        ownerId: 'user123'
      },
      {
        id: 'group2',
        name: 'Trip to Paris',
        description: 'Vacation expenses',
        members: [
          { id: 'user123', name: 'John Doe', email: 'john@example.com' },
          { id: 'user456', name: 'Jane Smith', email: 'jane@example.com' }
        ],
        createdAt: '2023-03-20T10:15:00Z',
        ownerId: 'user456'
      }
    ];
  },
  getExpenses: async (groupId: string) => {
    const expenses = [
      {
        id: 'exp1',
        groupId: 'group1',
        description: 'Groceries',
        amount: 89.50,
        paidBy: 'user123',
        splits: [
          { userId: 'user123', amount: 29.83, paid: true },
          { userId: 'user456', amount: 29.83, paid: false },
          { userId: 'user789', amount: 29.84, paid: false }
        ],
        date: '2023-04-10T15:20:00Z',
        category: 'Food'
      },
      {
        id: 'exp2',
        groupId: 'group1',
        description: 'Rent - April',
        amount: 1500,
        paidBy: 'user456',
        splits: [
          { userId: 'user123', amount: 500, paid: false },
          { userId: 'user456', amount: 500, paid: true },
          { userId: 'user789', amount: 500, paid: false }
        ],
        date: '2023-04-01T09:00:00Z',
        category: 'Housing'
      },
      {
        id: 'exp3',
        groupId: 'group2',
        description: 'Hotel Booking',
        amount: 620,
        paidBy: 'user456',
        splits: [
          { userId: 'user123', amount: 310, paid: false },
          { userId: 'user456', amount: 310, paid: true }
        ],
        date: '2023-03-25T12:45:00Z',
        category: 'Travel'
      }
    ];
    
    return expenses.filter(expense => expense.groupId === groupId);
  },
  getDashboardData: async () => {
    return {
      totalBalance: -380.17,
      groupSummaries: [
        { groupId: 'group1', groupName: 'Roommates', totalExpenses: 1589.50, userBalance: -470.17 },
        { groupId: 'group2', groupName: 'Trip to Paris', totalExpenses: 620, userBalance: 90 }
      ],
      recentActivity: [
        { id: 'act1', description: 'Jane added expense "Rent - April"', date: '2023-04-01T09:00:00Z', type: 'expense' },
        { id: 'act2', description: 'You added expense "Groceries"', date: '2023-04-10T15:20:00Z', type: 'expense' },
        { id: 'act3', description: 'Mike settled $45 with you', date: '2023-03-30T14:10:00Z', type: 'settlement' }
      ],
      notifications: [
        { id: 'notif1', userId: 'user123', message: 'Jane added a new expense in Roommates', read: false, createdAt: '2023-04-01T09:00:00Z', type: 'expense', relatedId: 'exp2' },
        { id: 'notif2', userId: 'user123', message: 'You owe Jane $500 for Rent - April', read: false, createdAt: '2023-04-01T09:00:00Z', type: 'expense', relatedId: 'exp2' },
        { id: 'notif3', userId: 'user123', message: 'You owe Jane $310 for Hotel Booking', read: true, createdAt: '2023-03-25T12:45:00Z', type: 'expense', relatedId: 'exp3' }
      ]
    };
  }
};