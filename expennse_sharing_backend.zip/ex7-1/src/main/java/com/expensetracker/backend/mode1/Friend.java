package com.expensetracker.backend.mode1;



import jakarta.persistence.*;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "friends")
@NoArgsConstructor
public class Friend {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String avatarUrl;
    private double balance;

    public Friend(String name, String email, String avatarUrl, double balance) {
        this.name = name;
        this.email = email;
        this.avatarUrl = avatarUrl;
        this.balance = balance;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public double getBalance() {
        return balance;
    }
}
