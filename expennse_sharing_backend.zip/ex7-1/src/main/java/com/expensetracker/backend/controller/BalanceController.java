package com.expensetracker.backend.controller;

import com.expensetracker.backend.mode1.Balance;
import com.expensetracker.backend.repository.BalanceRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/balances")
public class BalanceController {

    private final BalanceRepository balanceRepository;

    public BalanceController(BalanceRepository balanceRepository) {
        this.balanceRepository = balanceRepository;
    }

    @GetMapping
    public List<Balance> getAllBalances() {
        return balanceRepository.findAll();
    }
}
