package com.expensetracker.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.expensetracker.backend.mode1.Expense;
import org.springframework.stereotype.Repository;


@Repository
public interface ExpenseRepository extends JpaRepository<Expense, Long> {
}
