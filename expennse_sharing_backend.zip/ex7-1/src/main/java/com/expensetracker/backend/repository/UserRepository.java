package com.expensetracker.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.expensetracker.backend.mode1.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
}
