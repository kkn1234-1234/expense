package com.expensetracker.backend.controller;
import com.expensetracker.backend.mode1.Friend;

import com.expensetracker.backend.repository.FriendRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/friends")
@CrossOrigin(origins = "http://localhost:5173")
public class FriendController {

    private final FriendRepository friendRepository;

    public FriendController(FriendRepository friendRepository) {
        this.friendRepository = friendRepository;
    }

    @GetMapping
    public List<Friend> getAllFriends() {
        return friendRepository.findAll();
    }

    @PostMapping
    public Friend addFriend(@RequestBody Friend friend) {
        return friendRepository.save(friend);
    }
}